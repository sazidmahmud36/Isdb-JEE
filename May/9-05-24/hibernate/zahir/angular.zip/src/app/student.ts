export class Student {
  id:any;
  name:any;
  round:any;

  constructor(id:any,name:any,round:any){
    this.id=id;
    this.name=name;
    this.round=round;
  }
}
